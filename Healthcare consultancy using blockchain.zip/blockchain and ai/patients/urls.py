from django.contrib import admin
from django.conf.urls import url
from patients.views import patientlogincheck,patientsendsymptoms,patientsymtomsanalysis

urlpatterns = [
    
    #url(r'^patientlogincheck/', patientlogincheck, name="patientlogincheck"),
    #url(r'^patientsendsymptoms/', patientsendsymptoms, name="patientsendsymptoms"),

]
