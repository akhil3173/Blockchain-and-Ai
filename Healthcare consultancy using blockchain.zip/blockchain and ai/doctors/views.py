from django.shortcuts import render, redirect # type: ignore
from django.contrib import messages # type: ignore
from django.db.models import Sum # type: ignore
from converginblockchain.models import doctorregistrationmodel, patientregistrationmodel, doctorreplaysysmptoms
from patients.models import patientsymptomsanalysis, transactionsstore
import datetime
import time

def doctorlogincheck(request):
    if request.method == "POST":
        usid = request.POST.get('loginid')
        pswd = request.POST.get('password')
        try:
            check = doctorregistrationmodel.objects.get(loginid=usid, password=pswd)
            request.session['docid'] = check.id
            request.session['loggeddoc'] = check.doctorname
            status = check.status

            if status == "activated":
                return redirect('doctors/doctorspage.html')
            else:
                messages.error(request, 'Your account is not activated.')
                return redirect('doctor.html')
        except doctorregistrationmodel.DoesNotExist:
            messages.error(request, 'Invalid login details.')
    return render(request, 'doctor.html')

def doctoranalyzesysmptoms(request):
    patientsysmptoms = patientsymptomsanalysis.objects.all()
    return render(request, "doctors/doctoranalyzesysmptoms.html", {'object': patientsysmptoms})

def DoctorsSendPriscription(request):
    if request.method == 'GET':
        id = request.GET.get('id')
        patientid = request.GET.get('patientid')
        patientsysmptoms = patientsymptomsanalysis.objects.filter(id=id, status='waiting')
        patientAuth = patientregistrationmodel.objects.filter(id=patientid)
        return render(request, "doctors/writepricription.html", {'object': patientsysmptoms, 'object1': patientAuth})

def DoctorPriscription(request):
    if request.method == 'POST':
        patientid = request.POST.get("patientid")
        sysid = request.POST.get('sysid')
        prescription1 = request.POST.get('priscription1')
        prescription2 = request.POST.get('priscription2')
        prescription3 = request.POST.get('priscription3')
        price = request.POST.get('price')

        try:
            symptmodel = patientsymptomsanalysis.objects.get(id=sysid)
            patientAuth = patientregistrationmodel.objects.get(id=patientid)
        except (patientsymptomsanalysis.DoesNotExist, patientregistrationmodel.DoesNotExist):
            messages.error(request, 'Invalid patient or symptom data.')
            return redirect('doctors/doctoranalyzesysmptoms.html')

        blkchMoney = int(price) / 10
        docid = request.session.get('docid')
        doctorname = request.session.get('loggeddoc')
        responsedate = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        doctorreplaysysmptoms.objects.create(
            patientid=patientid, sysid=sysid, patinetname=symptmodel.patinetname,
            docid=docid, doctorname=doctorname, email=symptmodel.email,
            mobile=patientAuth.mobile, city=patientAuth.city, patinetallsymptoms=symptmodel.patinetallsymptoms,
            diseasname=symptmodel.diseasname, descriptions=symptmodel.descriptions,
            reqdate=symptmodel.createdon.strftime('%Y-%m-%d %H:%M:%S'),
            prescription1=prescription1, prescription2=prescription2, prescription3=prescription3,
            price=price, blkchMoney=blkchMoney, respdate=responsedate, status='waiting'
        )
        patientsymptomsanalysis.objects.filter(id=sysid).update(status='given', docname=doctorname)

    return redirect('doctors/doctoranalyzesysmptoms.html')

def purchaseviewbydoctor(request):
    id = request.session.get('docid')
    docdataset = doctorreplaysysmptoms.objects.filter(docid=id, status='purchase')
    return render(request, "doctors/purchaseviewbydoctor.html", {'object': docdataset})

def doctorviewtransaction(request):
    id = request.session.get('docid')
    ledbal = transactionsstore.objects.aggregate(Sum('ledgerbalance')).get("ledgerbalance__sum", 0) or 0
    ledbal = round(ledbal, 2)

    obj = transactionsstore.objects.filter(docid=id).last()
    userdata = transactionsstore.objects.filter(docid=id)

    return render(request, "doctors/doctorviewtransaction.html", {
        'object': userdata, 
        'dph': {'ledbalance': ledbal}, 
        'dpdet': obj
    })
